from ecommerce.customer import contact


def calc_tax():
    pass


def calc_shipping():
    pass


contact.contact_customer()
